var indexSectionsWithContent =
{
  0: "_abcdfhimprstvy",
  1: "crv",
  2: "m",
  3: "bi",
  4: "_abcdfhprsty"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "functions",
  3: "variables",
  4: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Files",
  2: "Functions",
  3: "Variables",
  4: "Macros"
};

