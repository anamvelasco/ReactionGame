var searchData=
[
  ['prev_5fblue_5fstate_0',['prev_blue_state',['../reflex__test_8c.html#a0253ad08f4aac7911fb03fd4e1490235',1,'reflex_test.c']]],
  ['prev_5fred_5fstate_1',['prev_red_state',['../reflex__test_8c.html#aec012c7e2b361398a78b29e259bb1e61',1,'reflex_test.c']]],
  ['prev_5fyellow_5fstate_2',['prev_yellow_state',['../reflex__test_8c.html#a3e356889e44624a5a7556681360e48cf',1,'reflex_test.c']]]
];
